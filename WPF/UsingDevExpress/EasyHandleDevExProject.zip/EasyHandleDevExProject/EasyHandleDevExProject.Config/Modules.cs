﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyHandleDevExProject.Config
{
    public static class Modules
    {
        public static string TESTModule { get { return "TESTModule"; } }
        public static string CLMModule { get { return "CLMModule"; } }
        public static string CLMModule2 { get { return "CLMModule2"; } }

        public static string SAMModule { get { return "SAMModule"; } }
        public static string SETModule { get { return "SETModule"; } }
    }
}
